// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xmyfunction.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XMyfunction_CfgInitialize(XMyfunction *InstancePtr, XMyfunction_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XMyfunction_Start(XMyfunction *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMyfunction_ReadReg(InstancePtr->Control_BaseAddress, XMYFUNCTION_CONTROL_ADDR_AP_CTRL) & 0x80;
    XMyfunction_WriteReg(InstancePtr->Control_BaseAddress, XMYFUNCTION_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XMyfunction_IsDone(XMyfunction *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMyfunction_ReadReg(InstancePtr->Control_BaseAddress, XMYFUNCTION_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XMyfunction_IsIdle(XMyfunction *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMyfunction_ReadReg(InstancePtr->Control_BaseAddress, XMYFUNCTION_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XMyfunction_IsReady(XMyfunction *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMyfunction_ReadReg(InstancePtr->Control_BaseAddress, XMYFUNCTION_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XMyfunction_EnableAutoRestart(XMyfunction *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMyfunction_WriteReg(InstancePtr->Control_BaseAddress, XMYFUNCTION_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XMyfunction_DisableAutoRestart(XMyfunction *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMyfunction_WriteReg(InstancePtr->Control_BaseAddress, XMYFUNCTION_CONTROL_ADDR_AP_CTRL, 0);
}

void XMyfunction_Set_Vsd(XMyfunction *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMyfunction_WriteReg(InstancePtr->Control_BaseAddress, XMYFUNCTION_CONTROL_ADDR_VSD_DATA, Data);
}

u32 XMyfunction_Get_Vsd(XMyfunction *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMyfunction_ReadReg(InstancePtr->Control_BaseAddress, XMYFUNCTION_CONTROL_ADDR_VSD_DATA);
    return Data;
}

void XMyfunction_Set_Vsq(XMyfunction *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMyfunction_WriteReg(InstancePtr->Control_BaseAddress, XMYFUNCTION_CONTROL_ADDR_VSQ_DATA, Data);
}

u32 XMyfunction_Get_Vsq(XMyfunction *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMyfunction_ReadReg(InstancePtr->Control_BaseAddress, XMYFUNCTION_CONTROL_ADDR_VSQ_DATA);
    return Data;
}

void XMyfunction_Set_iL(XMyfunction *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMyfunction_WriteReg(InstancePtr->Control_BaseAddress, XMYFUNCTION_CONTROL_ADDR_IL_DATA, Data);
}

u32 XMyfunction_Get_iL(XMyfunction *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMyfunction_ReadReg(InstancePtr->Control_BaseAddress, XMYFUNCTION_CONTROL_ADDR_IL_DATA);
    return Data;
}

u32 XMyfunction_Get_x_ini_BaseAddress(XMyfunction *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XMYFUNCTION_CONTROL_ADDR_X_INI_BASE);
}

u32 XMyfunction_Get_x_ini_HighAddress(XMyfunction *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XMYFUNCTION_CONTROL_ADDR_X_INI_HIGH);
}

u32 XMyfunction_Get_x_ini_TotalBytes(XMyfunction *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XMYFUNCTION_CONTROL_ADDR_X_INI_HIGH - XMYFUNCTION_CONTROL_ADDR_X_INI_BASE + 1);
}

u32 XMyfunction_Get_x_ini_BitWidth(XMyfunction *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMYFUNCTION_CONTROL_WIDTH_X_INI;
}

u32 XMyfunction_Get_x_ini_Depth(XMyfunction *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMYFUNCTION_CONTROL_DEPTH_X_INI;
}

u32 XMyfunction_Write_x_ini_Words(XMyfunction *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XMYFUNCTION_CONTROL_ADDR_X_INI_HIGH - XMYFUNCTION_CONTROL_ADDR_X_INI_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XMYFUNCTION_CONTROL_ADDR_X_INI_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XMyfunction_Read_x_ini_Words(XMyfunction *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XMYFUNCTION_CONTROL_ADDR_X_INI_HIGH - XMYFUNCTION_CONTROL_ADDR_X_INI_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XMYFUNCTION_CONTROL_ADDR_X_INI_BASE + (offset + i)*4);
    }
    return length;
}

u32 XMyfunction_Write_x_ini_Bytes(XMyfunction *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XMYFUNCTION_CONTROL_ADDR_X_INI_HIGH - XMYFUNCTION_CONTROL_ADDR_X_INI_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XMYFUNCTION_CONTROL_ADDR_X_INI_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XMyfunction_Read_x_ini_Bytes(XMyfunction *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XMYFUNCTION_CONTROL_ADDR_X_INI_HIGH - XMYFUNCTION_CONTROL_ADDR_X_INI_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XMYFUNCTION_CONTROL_ADDR_X_INI_BASE + offset + i);
    }
    return length;
}

u32 XMyfunction_Get_u00_BaseAddress(XMyfunction *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XMYFUNCTION_CONTROL_ADDR_U00_BASE);
}

u32 XMyfunction_Get_u00_HighAddress(XMyfunction *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XMYFUNCTION_CONTROL_ADDR_U00_HIGH);
}

u32 XMyfunction_Get_u00_TotalBytes(XMyfunction *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XMYFUNCTION_CONTROL_ADDR_U00_HIGH - XMYFUNCTION_CONTROL_ADDR_U00_BASE + 1);
}

u32 XMyfunction_Get_u00_BitWidth(XMyfunction *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMYFUNCTION_CONTROL_WIDTH_U00;
}

u32 XMyfunction_Get_u00_Depth(XMyfunction *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMYFUNCTION_CONTROL_DEPTH_U00;
}

u32 XMyfunction_Write_u00_Words(XMyfunction *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XMYFUNCTION_CONTROL_ADDR_U00_HIGH - XMYFUNCTION_CONTROL_ADDR_U00_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XMYFUNCTION_CONTROL_ADDR_U00_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XMyfunction_Read_u00_Words(XMyfunction *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XMYFUNCTION_CONTROL_ADDR_U00_HIGH - XMYFUNCTION_CONTROL_ADDR_U00_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XMYFUNCTION_CONTROL_ADDR_U00_BASE + (offset + i)*4);
    }
    return length;
}

u32 XMyfunction_Write_u00_Bytes(XMyfunction *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XMYFUNCTION_CONTROL_ADDR_U00_HIGH - XMYFUNCTION_CONTROL_ADDR_U00_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XMYFUNCTION_CONTROL_ADDR_U00_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XMyfunction_Read_u00_Bytes(XMyfunction *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XMYFUNCTION_CONTROL_ADDR_U00_HIGH - XMYFUNCTION_CONTROL_ADDR_U00_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XMYFUNCTION_CONTROL_ADDR_U00_BASE + offset + i);
    }
    return length;
}

u32 XMyfunction_Get_outputVector_BaseAddress(XMyfunction *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XMYFUNCTION_CONTROL_ADDR_OUTPUTVECTOR_BASE);
}

u32 XMyfunction_Get_outputVector_HighAddress(XMyfunction *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XMYFUNCTION_CONTROL_ADDR_OUTPUTVECTOR_HIGH);
}

u32 XMyfunction_Get_outputVector_TotalBytes(XMyfunction *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XMYFUNCTION_CONTROL_ADDR_OUTPUTVECTOR_HIGH - XMYFUNCTION_CONTROL_ADDR_OUTPUTVECTOR_BASE + 1);
}

u32 XMyfunction_Get_outputVector_BitWidth(XMyfunction *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMYFUNCTION_CONTROL_WIDTH_OUTPUTVECTOR;
}

u32 XMyfunction_Get_outputVector_Depth(XMyfunction *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMYFUNCTION_CONTROL_DEPTH_OUTPUTVECTOR;
}

u32 XMyfunction_Write_outputVector_Words(XMyfunction *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XMYFUNCTION_CONTROL_ADDR_OUTPUTVECTOR_HIGH - XMYFUNCTION_CONTROL_ADDR_OUTPUTVECTOR_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XMYFUNCTION_CONTROL_ADDR_OUTPUTVECTOR_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XMyfunction_Read_outputVector_Words(XMyfunction *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XMYFUNCTION_CONTROL_ADDR_OUTPUTVECTOR_HIGH - XMYFUNCTION_CONTROL_ADDR_OUTPUTVECTOR_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XMYFUNCTION_CONTROL_ADDR_OUTPUTVECTOR_BASE + (offset + i)*4);
    }
    return length;
}

u32 XMyfunction_Write_outputVector_Bytes(XMyfunction *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XMYFUNCTION_CONTROL_ADDR_OUTPUTVECTOR_HIGH - XMYFUNCTION_CONTROL_ADDR_OUTPUTVECTOR_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XMYFUNCTION_CONTROL_ADDR_OUTPUTVECTOR_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XMyfunction_Read_outputVector_Bytes(XMyfunction *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XMYFUNCTION_CONTROL_ADDR_OUTPUTVECTOR_HIGH - XMYFUNCTION_CONTROL_ADDR_OUTPUTVECTOR_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XMYFUNCTION_CONTROL_ADDR_OUTPUTVECTOR_BASE + offset + i);
    }
    return length;
}

void XMyfunction_InterruptGlobalEnable(XMyfunction *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMyfunction_WriteReg(InstancePtr->Control_BaseAddress, XMYFUNCTION_CONTROL_ADDR_GIE, 1);
}

void XMyfunction_InterruptGlobalDisable(XMyfunction *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMyfunction_WriteReg(InstancePtr->Control_BaseAddress, XMYFUNCTION_CONTROL_ADDR_GIE, 0);
}

void XMyfunction_InterruptEnable(XMyfunction *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMyfunction_ReadReg(InstancePtr->Control_BaseAddress, XMYFUNCTION_CONTROL_ADDR_IER);
    XMyfunction_WriteReg(InstancePtr->Control_BaseAddress, XMYFUNCTION_CONTROL_ADDR_IER, Register | Mask);
}

void XMyfunction_InterruptDisable(XMyfunction *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMyfunction_ReadReg(InstancePtr->Control_BaseAddress, XMYFUNCTION_CONTROL_ADDR_IER);
    XMyfunction_WriteReg(InstancePtr->Control_BaseAddress, XMYFUNCTION_CONTROL_ADDR_IER, Register & (~Mask));
}

void XMyfunction_InterruptClear(XMyfunction *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMyfunction_WriteReg(InstancePtr->Control_BaseAddress, XMYFUNCTION_CONTROL_ADDR_ISR, Mask);
}

u32 XMyfunction_InterruptGetEnabled(XMyfunction *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMyfunction_ReadReg(InstancePtr->Control_BaseAddress, XMYFUNCTION_CONTROL_ADDR_IER);
}

u32 XMyfunction_InterruptGetStatus(XMyfunction *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMyfunction_ReadReg(InstancePtr->Control_BaseAddress, XMYFUNCTION_CONTROL_ADDR_ISR);
}

