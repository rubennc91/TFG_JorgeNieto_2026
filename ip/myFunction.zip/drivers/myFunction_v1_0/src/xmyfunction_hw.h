// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read)
//        bit 7  - auto_restart (Read/Write)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0  - enable ap_done interrupt (Read/Write)
//        bit 1  - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0  - ap_done (COR/TOW)
//        bit 1  - ap_ready (COR/TOW)
//        others - reserved
// 0x20 : Data signal of Vsd
//        bit 31~0 - Vsd[31:0] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of Vsq
//        bit 31~0 - Vsq[31:0] (Read/Write)
// 0x2c : reserved
// 0x30 : Data signal of iL
//        bit 31~0 - iL[31:0] (Read/Write)
// 0x34 : reserved
// 0x10 ~
// 0x1f : Memory 'x_ini' (3 * 32b)
//        Word n : bit [31:0] - x_ini[n]
// 0x38 ~
// 0x3f : Memory 'u00' (2 * 32b)
//        Word n : bit [31:0] - u00[n]
// 0x40 ~
// 0x47 : Memory 'outputVector' (2 * 32b)
//        Word n : bit [31:0] - outputVector[n]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XMYFUNCTION_CONTROL_ADDR_AP_CTRL           0x00
#define XMYFUNCTION_CONTROL_ADDR_GIE               0x04
#define XMYFUNCTION_CONTROL_ADDR_IER               0x08
#define XMYFUNCTION_CONTROL_ADDR_ISR               0x0c
#define XMYFUNCTION_CONTROL_ADDR_VSD_DATA          0x20
#define XMYFUNCTION_CONTROL_BITS_VSD_DATA          32
#define XMYFUNCTION_CONTROL_ADDR_VSQ_DATA          0x28
#define XMYFUNCTION_CONTROL_BITS_VSQ_DATA          32
#define XMYFUNCTION_CONTROL_ADDR_IL_DATA           0x30
#define XMYFUNCTION_CONTROL_BITS_IL_DATA           32
#define XMYFUNCTION_CONTROL_ADDR_X_INI_BASE        0x10
#define XMYFUNCTION_CONTROL_ADDR_X_INI_HIGH        0x1f
#define XMYFUNCTION_CONTROL_WIDTH_X_INI            32
#define XMYFUNCTION_CONTROL_DEPTH_X_INI            3
#define XMYFUNCTION_CONTROL_ADDR_U00_BASE          0x38
#define XMYFUNCTION_CONTROL_ADDR_U00_HIGH          0x3f
#define XMYFUNCTION_CONTROL_WIDTH_U00              32
#define XMYFUNCTION_CONTROL_DEPTH_U00              2
#define XMYFUNCTION_CONTROL_ADDR_OUTPUTVECTOR_BASE 0x40
#define XMYFUNCTION_CONTROL_ADDR_OUTPUTVECTOR_HIGH 0x47
#define XMYFUNCTION_CONTROL_WIDTH_OUTPUTVECTOR     32
#define XMYFUNCTION_CONTROL_DEPTH_OUTPUTVECTOR     2

